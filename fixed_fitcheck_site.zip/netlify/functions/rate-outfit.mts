import type { Context } from '@netlify/functions'
import { GoogleGenAI } from '@google/genai'

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || 'AIzaSyDC9Su49o2vPr9wIgUjrJCRuWS3-xN43Qc'
})

const PROMPT = `You are a sharp, brutally honest fashion critic. Analyse this outfit photo.

Return ONLY a raw JSON object — no markdown fences, no extra text:
{
  "score": <integer 1-10>,
  "verdict": "<punchy 2-3 word title e.g. 'Clean Minimalist' or 'Needs Direction'>",
  "subtitle": "<one sentence style read>",
  "feedback": "<2-3 sentences: honest but constructive critique>",
  "good_tags": ["<strength>", "<strength>"],
  "bad_tags": ["<weakness>", "<weakness>"]
}

Score guide: 8-10 = genuinely great, 5-7 = average with potential, 1-4 = significant work needed. Be real, not nice.`

export default async (req: Request, _context: Context) => {
  if (req.method !== 'POST') {
    return new Response('Method not allowed', { status: 405 })
  }

  let imageBase64: string
  let imageMimeType: string

  try {
    const body = await req.json()
    imageBase64 = body.imageBase64
    imageMimeType = body.imageMimeType
  } catch {
    return Response.json({ error: 'Invalid request body' }, { status: 400 })
  }

  if (!imageBase64 || !imageMimeType) {
    return Response.json({ error: 'Missing image data' }, { status: 400 })
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [
        {
          role: 'user',
          parts: [
            { text: PROMPT },
            { inlineData: { mimeType: imageMimeType, data: imageBase64 } }
          ]
        }
      ],
      config: {
        temperature: 0.7,
        maxOutputTokens: 500,
        responseMimeType: 'application/json'
      }
    })

    const text = response.text

    if (!text || text.trim() === '') {
      return Response.json(
        { error: 'AI returned empty response' },
        { status: 500 }
      )
    }

    let parsed

    try {
      const cleaned = text.replace(/```json|```/g, '').trim()
      parsed = JSON.parse(cleaned)
    } catch {
      return Response.json(
        {
          error: 'AI returned invalid JSON',
          raw: text
        },
        { status: 500 }
      )
    }

    return Response.json(parsed)
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error'
    return Response.json({ error: message }, { status: 500 })
  }
}

export const config = {
  path: '/api/rate-outfit',
}
